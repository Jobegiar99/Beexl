En esta avance ya se generan cuadruplos para expresiones lineales,
codicionales, ciclos y otros elementos de nuestro lenguaje. 

Tambien se empezó a implementar el manejo de errores de redefinicion de variables globales.

https://github.com/Jobegiar99/Beexl